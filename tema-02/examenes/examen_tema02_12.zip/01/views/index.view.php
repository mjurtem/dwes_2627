<!doctype html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Examen práctico 03</title>

    <!-- css bootstrap 5.3.8 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">

    <!-- iconos bootstrap 1.13.1 -->
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
  </head>
  <body>
    <!-- capa principal de la aplicacion -->
    <div class="container mt-3">
        <!-- cabecera  de la aplicacion -->
        <header class="bg-primary text-white p-3 mb-3">
            <i class="bi bi-speedometer2"></i>
            <span class="fs-6">Examen práctico 03 - Movimiento rectilíneo uniformemente acelerado</span>
        </header>

         <!-- contenido principal de la aplicacion -->
         <main>
            <div class="content">
                <form method="post">
                    <div class="mb-3">
                        <label for="velocidad_inicial" class="form-label">Velocidad Inicial (m/s)</label>
                        <input type="number" class="form-control" id="velocidad_inicial" name="velocidad_inicial" required>
                    </div>

                    <div class="mb-3">
                        <label for="aceleracion" class="form-label">Aceleración (m/s2)</label>
                        <input type="number" class="form-control" id="aceleracion" name="aceleracion" required>
                    </div>

                    <div class="mb-3">
                        <label for="aceleracion" class="form-label">Tiempo (s)</label>
                        <input type="number" class="form-control" id="tiempo" name="tiempo" required>
                    </div>

                    <div class="mb-3">
                        <label for="aceleracion" class="form-label">Masa (kg)</label>
                        <input type="number" class="form-control" id="masa" name="masa" required>
                    </div>
                    
                    <div>
                        <button type="submit" class="btn btn-warning" name="calcular" value="calcular" formaction="calcular.php">Calcular</button>
                        <button type="reset" class="btn btn-danger">Borrar</button>
                    </div>
                    </div>
                </form>
            </div>
         </main>

        <!-- pie de pagina de la aplicacion -->
        <footer class="footer mt-auto py-3 fixed-bottom bg-light">
            <div class="container">
                <span class="text-muted">&copy; 2026 Miguel A. Jurado Temblador - 
                    DWES - 2º DAW - Curso 26/27
                </span>
            </div>
        </footer>

        <!-- js bootstrap basico 5.3.8 -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    </div>
  </body>
</html>